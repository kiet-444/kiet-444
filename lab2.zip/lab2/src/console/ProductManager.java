package console;

import ctrl.ProductCtrl;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import model.dto.ProductDTO;

/**
 *
 * @author 
 */
public class ProductManager {

    private ProductCtrl ctrl;

    public ProductManager() {
    }

    public void createProduct(Scanner sc) {
        ctrl = new ProductCtrl();
        ProductDTO product = new ProductDTO();

        System.out.print("Enter product ID: ");
        int id = getInt(sc);
        while (id < 0) {
            System.out.print("Enter product ID again: ");
            id = getInt(sc);        
        }

        System.out.print("Enter product name: ");
        String name = getString(sc, 5);
        while (name == null) {
            System.out.print("Enter product name again: ");
            name = getString(sc, 5);
        }

        System.out.print("Enter product price: ");
        int price = getInt(sc);
        while (price < 0 || price > 10000) {
            if (price > 10000) {
                System.out.println("A UnitPrice field is a real number and ranges from 0 to 10000");
            }
            System.out.print("Enter product price again: ");
            price = getInt(sc);
        }

        System.out.print("Enter product quantity: ");
        int quantity = getInt(sc);
        while (quantity < 0 || quantity > 1000) {
            if (quantity > 1000) {
                System.out.println("A Quantity field is an integer number and ranges from 0 to 1000.");
            }
            System.out.print("Enter product quantity again: ");
            quantity = getInt(sc);
        }
        System.out.print("Enter product status: ");
        int status = getStatus(sc);
        while (status < 0) {
            System.out.print("Enter product status again: ");
            status = getStatus(sc);
        }

        product.setId(id);
        product.setName(name);
        product.setQuantity(quantity);
        product.setUnitPrice(price);
        product.setStatus((status == 1));

        Map<String, Object> response = ctrl.create(product);

        if (response.containsKey("success") && response.get("success").equals("1")) {
            System.out.println("Insert " + response.get("product") + " success.");
        } else if (response.containsKey("error")) {
            System.out.println(response.get("error"));
        } else {
            System.out.println("Unknown system error.");
        }
        System.out.println("--------------------------------------------------");

    }

    public void checkExist(Scanner sc) {
        ctrl = new ProductCtrl();
        System.out.print("Enter product ID you want to check: ");
        int id = getInt(sc);
        while (id < 0) {
            System.out.print("Enter product ID again: ");
            id = getInt(sc);
        }

        Map<String, Object> response = ctrl.findById(id);

        if (response.containsKey("product")) {
            Object product = response.get("product");
            System.out.println("Exist Product " + product);
        } else if (response.containsKey("error")) {
            System.out.println(response.get("error"));
        } else {
            System.out.println("Unknown system error.");
        }
        System.out.println("--------------------------------------------------");

    }

    public void searchByName(Scanner sc) {
        ctrl = new ProductCtrl();
        System.out.print("Enter product name you want to search: ");
        String name = getString(sc, 0);
        while (name == null) {
            System.out.print("Enter product name again: ");
            name = getString(sc, 0);
        }

        Map<String, Object> response = ctrl.search(name);

        if (response.containsKey("products")) {
            List<ProductDTO> products = (List<ProductDTO>) response.get("products");
            products.stream().sorted((o1, o2) -> {
                return o1.getName().compareTo(o2.getName());
                //To change body of generated lambdas, choose Tools | Templates.
            }).forEach(System.out::println);
        } else if (response.containsKey("error")) {
            System.out.println(response.get("error"));
        } else {
            System.out.println("Unknown system error.");
        }
        System.out.println("--------------------------------------------------");

    }

    public void printAll() {
        ctrl = new ProductCtrl();
        Map<String, Object> res = ctrl.findAll();
        if (res.containsKey("products")) {
            List<ProductDTO> products = (List<ProductDTO>) res.get("products");
            products.stream().sorted((o1, o2) -> {
                return o1.getQuantity() - o2.getQuantity() != 0
                        ? o2.getQuantity() - o1.getQuantity()
                        : o1.getUnitPrice() - o2.getUnitPrice();
            }).forEach(System.out::println);
        } else if (res.containsKey("error")) {
            System.out.println(res.get("error"));
        } else {
            System.out.println("Unknown system error.");
        }
        System.out.println("--------------------------------------------------");

    }

    void deleteByID(Scanner sc) {
        ctrl = new ProductCtrl();
        System.out.print("Enter product ID you want to DELETE: ");
        int id = getInt(sc);
        while (id < 0) {
            System.out.print("Enter product ID again: ");
            id = getInt(sc);
        }

        Map<String, Object> response = ctrl.delete(id);

        if (response.containsKey("success") && response.get("success").equals("1")) {
            System.out.println("Delete product with id=" + id + " success.");
        } else if (response.containsKey("error")) {
            System.out.println(response.get("error"));
        } else {
            System.out.println("Unknown system error.");
        }
        System.out.println("--------------------------------------------------");
    }

    public void updateByID(Scanner sc) {
        ctrl = new ProductCtrl();
        System.out.print("Enter product ID you want to check: ");
        int id = getInt(sc);
        while (id < 0) {
            System.out.print("Enter product ID again: ");
            id = getInt(sc);
        }

        Map<String, Object> response = ctrl.findById(id);

        if (response.containsKey("product")) {
            ProductDTO product = (ProductDTO) response.get("product");
            //begin to edit product
            System.out.print("Enter new product name: ");
            String name = getString(sc, 5);
            while (name == null) {
                System.out.print("Enter product name again: ");
                name = getString(sc, 5);
            }

            System.out.print("Enter new product price: ");
            int price = getInt(sc);
            while (price < 0 || price > 10000) {
                if (price > 10000) {
                    System.out.println("A UnitPrice field is a real number and ranges from 0 to 10000");
                }
                System.out.print("Enter new product price again: ");
                price = getInt(sc);
            }

            System.out.print("Enter new product quantity: ");
            int quantity = getInt(sc);
            while (quantity < 0 || quantity > 1000) {
                if (quantity > 1000) {
                    System.out.println("A Quantity field is an integer number and ranges from 0 to 1000.");
                }
                System.out.print("Enter product quantity again: ");
                quantity = getInt(sc);
            }
            System.out.print("Enter new product status: ");
            int status = getStatus(sc);
            while (status < 0) {
                System.out.print("Enter product status again: ");
                status = getStatus(sc);
            }

            product.setName(name);
            product.setQuantity(quantity);
            product.setUnitPrice(price);
            product.setStatus(status == 1 ? true : false);

            Map<String, Object> updateRes = ctrl.update(product);

            if (updateRes.containsKey("success") && updateRes.get("success").equals("1")) {
                System.out.println(updateRes.get("message"));
            } else if (updateRes.containsKey("error")) {
                System.out.println(updateRes.get("error"));
            } else {
                System.out.println("Unknown system error.");
            }

        } else if (response.containsKey("error")) {
            System.out.println("Productname does not exist");
        } else {
            System.out.println("Unknown system error.");
        }
        System.out.println("--------------------------------------------------");
    }

    //utils
    private int getInt(Scanner sc) {
        try {
           String input = sc.nextLine();
            return Integer.parseInt(input);
        } catch (NumberFormatException ime) {
            System.out.println("Error: The input does not match the Integer regular expression.");
        }
        return -1;
    }
    //sẽ có lỗi dữ liệu lõi
    //khi nhập vào kí tự inter nên nhập vào String sau àoó dùng hàm integer.parseInt(input)
    //do sc.nextInt nó quăng ra một cái lỗi qua exception nhưng không nhận được lỗi
    //làm cho tạo dòng lập vô tận do lỗi đâu khi nhập chữ thay vì số

    private int getStatus(Scanner sc) {
        String input = sc.nextLine();
        if (input.trim().toLowerCase().equals("true") || input.trim().equals("1")) {
            return 1;
        } else if (input.trim().toLowerCase().equals("false") || input.trim().equals("0")) {
            return 0;
        } else {
            System.out.println("Error: the input is not a valid boolean");
            return -1;
        }
    }

    private String getString(Scanner sc, int minLength) {
        String input = sc.nextLine();
        if (input.trim().length() <= minLength) {
            return null;
        }
        return input.trim();
    }

}
