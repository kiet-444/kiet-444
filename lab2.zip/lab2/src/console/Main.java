package console;

import java.util.Scanner;

/**
 *
 * @author 
 */
public class Main {

    private final Scanner sc;
    private final ProductManager manager;

    public Main() {
        sc = new Scanner(System.in);
        manager = new ProductManager();
    }

    public static void main(String[] args) {
        new Main().excute();
    }

    public void printMenu() {
        System.out.println("1. Create a Product");
        System.out.println("2. Check exits Product.");
        System.out.println("3. Search Product’ information by Name");
        System.out.println("4. Update Product:");
        System.out.println("4.1. Update Product.");
        System.out.println("4.2. Delete Product.");
        System.out.println("5. Save Products to file");
        System.out.println("6. Print list Products from the file.");
        System.out.println("Others- Quit.");
    }

    public void excute() {
        String input;
        while (true) {
            printMenu();
            System.out.print("user@product-management:~$ ");
            input = sc.nextLine();
            switch (input) {
                case "1":
                    manager.createProduct(sc);
                    break;
                case "2":
                    manager.checkExist(sc);
                    break;
                case "3":
                    manager.searchByName(sc);
                    break;
                case "4":
                    break;
                case "4.1":
                    manager.updateByID(sc);
                    break;
                case "4.2":
                    manager.deleteByID(sc);
                    break;
                case "5":
                    System.out.println("The data will be automatically saved to "
                            + "the file or database every time there is any operation, "
                            + "so there is no need to perform this function.");
                    break;
                case "6":
                    manager.printAll();
                    break;
                default:
                    sc.close();
                    System.exit(0);
            }
        }
    }
}
