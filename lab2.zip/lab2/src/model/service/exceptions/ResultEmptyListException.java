/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.service.exceptions;

/**
 *
 * @author 
 */
public class ResultEmptyListException extends Exception {

    public ResultEmptyListException(String message) {
        super(message);
    }

    public ResultEmptyListException(String message, Throwable cause) {
        super(message, cause);
    }

}
