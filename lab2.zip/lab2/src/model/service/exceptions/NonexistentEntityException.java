package model.service.exceptions;

/**
 *
 * @author 
 */
// định nghĩa exception private 
public class NonexistentEntityException extends Exception {

    public NonexistentEntityException(String message) {
        super(message);
    }

    public NonexistentEntityException(String message, Throwable cause) {
        super(message, cause);
    }

}
