package model.service;

import model.service.exceptions.ResultEmptyListException;
import model.service.exceptions.PreexistingEntityException;
import model.dao.ProductDAO;
import model.dto.ProductDTO;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import model.service.exceptions.NonexistentEntityException;

/**
 *
 * @author 
 */
// xử lý dữ liệu 
// xử lý trước khi đưa vào database
//nghiệp vụ logic hỗ trợ tính toán ......
public class ProductService {

    private final ProductDAO dao;

    public ProductService() {
        dao = new ProductDAO();
    }

    public void create(ProductDTO product) throws PreexistingEntityException {
        Map<Integer, ProductDTO> products = dao.readAll();
        //Check dulicate id
        if (products.containsKey(product.getId())) {
            throw new PreexistingEntityException("Product with id " + product.getId() + " already exists.");
        }
        //Check dulicate name
        Optional<ProductDTO> isNameDuplicate = products.values().stream()
                .filter(e -> e.getName().toLowerCase().equals(product.getName().toLowerCase()))
                .findAny();
        if (isNameDuplicate.isPresent()) {
            throw new PreexistingEntityException("Product with name " + product.getName() + " already exists.");
        }
        products.put(product.getId(), product);
        dao.write(products);
    }

    public void update(ProductDTO product) throws NonexistentEntityException, PreexistingEntityException {
        Map<Integer, ProductDTO> products = dao.readAll();
        //Check if updated product name is dulicated with exist product name
        Optional<ProductDTO> isNameDuplicate = products.values().stream()
                .filter(e -> e.getName().toLowerCase().equals(product.getName().toLowerCase()))
                .findAny();
        if (isNameDuplicate.isPresent()) {
            throw new PreexistingEntityException("Product with name " + product.getName() + " already exists.");
        }
        if (products.containsKey(product.getId())) {
            products.replace(product.getId(), product);
            dao.write(products);
        } else {
            throw new NonexistentEntityException("The product with id " + product.getId() + " no longer exists.");
        }
    }

    public ProductDTO findByID(Integer id) throws NonexistentEntityException {
        Map<Integer, ProductDTO> products = dao.readAll();
        if (products.containsKey(id)) {
            return products.get(id);
        } else {
            throw new NonexistentEntityException("The product with id " + id + " no longer exists.");
        }
    }

    public List<ProductDTO> findAll() throws ResultEmptyListException {
        Map<Integer, ProductDTO> products = dao.readAll();
        if (products.isEmpty()) {
            throw new ResultEmptyListException("There are no records in the system.");
        }
        return products.values().stream().collect(Collectors.toList());
    }

    public void deleteByID(Integer id) throws NonexistentEntityException {
        Map<Integer, ProductDTO> products = dao.readAll();
        if (products.containsKey(id)) {
            products.remove(id);
            dao.write(products);
        } else {
            throw new NonexistentEntityException("The product with id " + id + " no longer exists.");
        }
    }

    public List<ProductDTO> search(String keyWord) throws ResultEmptyListException {
        Map<Integer, ProductDTO> products = dao.readAll();
        if (products.isEmpty()) {
            throw new ResultEmptyListException("There are no records in the system.");
        }

        List<ProductDTO> collect = products.values().stream()
                .filter(e -> Pattern.matches(".*" + keyWord.toLowerCase() + ".*", e.getName().toLowerCase()))
                .collect(Collectors.toList());
        if (collect.isEmpty()) {
            throw new ResultEmptyListException("There are no records match with keyword in the system.");
        }
        return collect;
    }

}
