package model.dto;

import java.io.Serializable;
import lombok.ToString;

/**
 *
 * @author 
 */
// dùng thư viện lombok
// trong đó dùng data là tiện nhất thay vì dùng get và set
//giúp tối giảng code 

@lombok.Data
@lombok.ToString
public class ProductDTO implements Serializable {
    @ToString.Include
    private int id;
    @ToString.Include
    private String name;
    @ToString.Include
    private int unitPrice;
    @ToString.Include
    private int quantity;
    @ToString.Include
    private Boolean status;
}
