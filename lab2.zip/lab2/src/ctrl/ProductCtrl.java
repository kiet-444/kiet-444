package ctrl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import model.dto.ProductDTO;
import model.service.ProductService;
import model.service.exceptions.NonexistentEntityException;
import model.service.exceptions.PreexistingEntityException;
import model.service.exceptions.ResultEmptyListException;

/**
 *
 * @author 
 */
public class ProductCtrl {

    private final ProductService service;
    private Map<String, Object> response;

    public ProductCtrl() {
        service = new ProductService();
        response = new HashMap<>();
    }

    public Map<String, Object> create(ProductDTO product) {
        try {
            service.create(product);
            response.put("success", "1");
            response.put("message", "Add product success.");
            response.put("product", product);
        } catch (PreexistingEntityException ex) {
            response.put("error", ex.getMessage());
        }
        return response;
    }

    public Map<String, Object> update(ProductDTO product) {
        try {
            service.update(product);
            response.put("success", "1");
            response.put("message", "Updated product success.");
            response.put("product", product);
        } catch (NonexistentEntityException | PreexistingEntityException ex) {
            response.put("error", ex.getMessage());
        }
        return response;
    }

    public Map<String, Object> delete(int id) {
        try {
            service.deleteByID(id);
            response.put("success", "1");
            response.put("message", "Deleted product success.");
        } catch (NonexistentEntityException ex) {
            response.put("error", "ProductID does not exist");
        }
        return response;
    }

    public Map<String, Object> findAll() {
        List<ProductDTO> products = new ArrayList<>();
        try {
            products = service.findAll();
        } catch (ResultEmptyListException ex) {
            response.put("error", ex.getMessage());
        }
        response.put("products", products);
        return response;
    }

    public Map<String, Object> findById(Integer id) {
        ProductDTO product = null;
        try {
            product = service.findByID(id);
            response.put("product", product);
        } catch (NonexistentEntityException ex) {
            response.put("error", "No Product Found!");
        }
        return response;
    }

    public Map<String, Object> search(String keyWord) {
        List<ProductDTO> products = new ArrayList<>();
        try {
            products = service.search(keyWord);
            response.put("products", products);
        } catch (ResultEmptyListException ex) {
            response.put("error", "Have no any Product");
        }
        return response;
    }
}
